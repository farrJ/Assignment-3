package cs2321;

import java.util.Comparator;

import net.datastructures.*;

/**
 * A Adaptable PriorityQueue based on an heap.
 * 
 * Course: CS2321 Section ALL Assignment: #3
 * 
 * @author
 */

public class HeapAPQ<K, V> implements AdaptablePriorityQueue<K, V> {

	protected ArrayList<Entry<K, V>> heap = new ArrayList<>(); // Primary collection of priority queue entries

	protected int parent(int j) { // truncating division
		return (j - 1) / 2;
	}

	protected int left(int j) {
		return 2 * j + 1;
	}

	protected int right(int j) {
		return 2 * j + 2;
	}

	protected boolean hasLeft(int j) {
		return left(j) < heap.size();
	}

	protected boolean hasRight(int j) {
		return right(j) < heap.size();
	}

	// Exchanges the entries at indices i and j of the array list.
	protected void swap(int i, int j) {
		Entry<K, V> temp = heap.get(i);
		heap.set(i, heap.get(j));
		heap.set(j, temp);
		((apqEntry<K, V>) heap.get(i)).setIndex(i);
		((apqEntry<K, V>) heap.get(j)).setIndex(j);

	}

	public static class DefaultComparator<K> implements Comparator<K> {

		// This compare method simply calls the compareTo method of the argument.
		// If the argument is not a Comparable object, and therefore there is no
		// compareTo method,
		// it will throw ClassCastException.
		public int compare(K a, K b) throws IllegalArgumentException {
			if (a instanceof Comparable) {
				return ((Comparable<K>) a).compareTo(b);
			} else {
				throw new IllegalArgumentException();
			}
		}
	}

	/**
	 * This provides a nested apqEntry class that composes a key and a value into a
	 * single object, and support for managing a comparator.
	 * 
	 * @author jfarr
	 *
	 * @param <K>
	 * @param <V>
	 */
	private static class apqEntry<K, V> implements Entry<K, V> {
		private int index;
		private K k; // Key
		private V v; // Value

		public apqEntry(K key, V value, int j) {
			k = key;
			v = value;
			index = j;
		}

		// Methods of Entry Interface
		@Override
		public K getKey() {
			return k;
		}

		@Override
		public V getValue() {
			return v;
		}

		public int getIndex() {
			return index;
		}

		public void setIndex(int j) {
			index = j;
		}

		// utilities not exposed as part of the Entry interface
		protected void setKey(K key) {
			k = key;
		}

		protected void setValue(V value) {
			v = value;
		}

	}

	// Moves the entry at index j higher, if necessary, to restore the heap property
	protected void upheap(int j) {
		while (j > 0) { // continue until reaching root (or break statement)
			int p = parent(j);
			if (compare(heap.get(j), heap.get(p)) >= 0)
				break; // heap property verified swap(j, p);
			swap(j, p);
			j = p; // continue from the parent's location
		}
	}

	// Moves the entry at index j lower,if necessary,to restore the heap property

	protected void downheap(int j) {
		while (hasLeft(j)) { // continue to bottom (or break statement)
			int leftIndex = left(j);
			int smallChildIndex = leftIndex; // although right may be smaller
			if (hasRight(j)) {
				int rightIndex = right(j);
				if (compare(heap.get(leftIndex), heap.get(rightIndex)) > 0)
					smallChildIndex = rightIndex; // right child is smaller
			}
			if (compare(heap.get(smallChildIndex), heap.get(j)) >= 0)
				break; // heap property has been restored
			swap(j, smallChildIndex);
			j = smallChildIndex; // continue at position of the child
		}
	}

	protected apqEntry<K, V> validate(Entry<K, V> entry) throws IllegalArgumentException {
		if (!(entry instanceof apqEntry))
			throw new IllegalArgumentException("Invalid entry");
		apqEntry<K, V> locator = (apqEntry<K, V>) entry;
		int j = locator.getIndex();
		if (j >= heap.size() || heap.get(j) != locator)
			throw new IllegalArgumentException("Invalid entry");
		return locator;
	}

	protected void bubble(int j) {
		if (j > 0 && compare(heap.get(j), heap.get(parent(j))) < 0)
			upheap(j);
		else
			downheap(j); // although it might not need to move
	}

	private Comparator<K> comp;

	protected int compare(Entry<K, V> a, Entry<K, V> b) {
		return comp.compare(a.getKey(), b.getKey());
	}

	protected boolean checkKey(K key) throws IllegalArgumentException {
		try {
			return (comp.compare(key, key) == 0); // see if key can be compared to itself
		} catch (ClassCastException e) {
			throw new IllegalArgumentException("Incompatible key");
		}
	}

	/*
	 * If no comparator is provided, use the default comparator. See the inner class
	 * DefaultComparator above. If no initial capacity is specified, use the default
	 * initial capacity.
	 */
	// Creates an empty priority queue based on the natural ordering of its keys.
	public HeapAPQ() {
		this(new DefaultComparator<K>());
	}

	/* Start the PQ with specified initial capacity */
	public HeapAPQ(int capacity) {
		ArrayList<Entry<K, V>> heap = new ArrayList<>(capacity);
	}

	/* Use specified comparator */
	public HeapAPQ(Comparator<K> c) {
		comp = c;
	}

	/* Use specified comparator and the specified initial capacity */
	public HeapAPQ(Comparator<K> c, int capacity) {
		ArrayList<Entry<K, V>> heap = new ArrayList<>(capacity);
		comp = c;
	}

	/*
	 * Return the array in arraylist that is used to store entries This method is
	 * purely for testing purpose of auto-grader
	 */
	public Object[] data() {
		// TODO: replace the line below to return the actual array in arraylist
		// TODO: You may want to add a method in your arrayList implementation
		// TODO: to allow the access to the array.

		return heap.data();
	}

	@Override
	public int size() {
		return heap.size();
	}

	@Override
	public boolean isEmpty() {
		return size() == 0;
	}

	@Override
	/**
	 * Inserts a key-value pair and returns the entry created.
	 */
	public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
		checkKey(key); // auxiliary key-checking method (could throw exception)
		Entry<K, V> newest = new apqEntry<>(key, value, heap.size());
		heap.addLast(newest); // add to the end of the list
		upheap(heap.size() - 1); // up-heap newly added entry
		return newest;

	}

	@Override
	/**
	 * Returns (but does not remove) an entry with minimal key (if any).
	 */
	public Entry<K, V> min() {
		if (heap.isEmpty())
			return null;
		return heap.get(0);

	}

	/**
	 * Removes and returns an entry with minimal key (if any)
	 */
	@Override
	public Entry<K, V> removeMin() {
		if (heap.isEmpty())
			return null;
		Entry<K, V> answer = heap.get(0);
		swap(0, heap.size() - 1); // put minimum item at the end
		heap.remove(heap.size() - 1); // and remove it from the list;
		downheap(0); // then fix new root
		return answer;

	}

	@Override
	public void remove(Entry<K, V> entry) throws IllegalArgumentException {
		apqEntry<K, V> locator = validate(entry);
		int j = locator.getIndex();
		if (j == heap.size() - 1)
			heap.remove(heap.size() - 1);
		else {
			swap(j, heap.size() - 1);
			heap.remove(heap.size() - 1);
			bubble(j);
		}

	}

	@Override
	public void replaceKey(Entry<K, V> entry, K key) throws IllegalArgumentException {
		apqEntry<K, V> locator = validate(entry);
		checkKey(key);
		locator.setKey(key);
		bubble(locator.getIndex());

	}

	@Override
	public void replaceValue(Entry<K, V> entry, V value) throws IllegalArgumentException {
		apqEntry<K, V> locator = validate(entry);
		locator.setValue(value);

	}

}
