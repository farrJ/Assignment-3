package cs2321;

import java.util.Iterator;

import net.datastructures.List;

public class ArrayList<E> implements List<E> {
	private E[] array;
	private int size = 0;
	private int capacity = 16;
	//TODO: add class members
	
	
	private class ArrayListIterator implements Iterator<E> {
		//TODO: add class members
		private int index = 0;
		
		@Override
		public boolean hasNext() {
			return index < size;
		}

		@Override
		public E next() {
			E e = array[index++];
			return e;
		}
		
	}

	public ArrayList() {
		// Default capacity: 16
		array = (E[]) new Object[capacity];
		
	}

	public ArrayList(int capacity) {
		this.capacity = capacity;
		array = (E[]) new Object[capacity];
	}
	
	@Override
	public int size() {
		return size;
	}

	// Return the current capacity of array, not the number of elements.
	// Notes: The initial capacity is 16. When the array is full, the array should be doubled. 
	public int capacity() {
		
		return capacity;
	}
	
	
	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	@Override
	public E get(int i) throws IndexOutOfBoundsException {
		if (i < 0 || i >= size) throw new IndexOutOfBoundsException();
		return array[i];
	}

	@Override
	public E set(int i, E e) throws IndexOutOfBoundsException {
		if (i < 0 || i >= size) throw new IndexOutOfBoundsException();
		 E old = array[i];
		 array[i] = e;
		 return old;
	}

	@Override
	public void add(int i, E e) throws IndexOutOfBoundsException {
		if(i < 0 || i > size) throw new IndexOutOfBoundsException(); //check whether index is valid
		
		if(size == array.length) {	//if array is full, expand it
			expandArray();
		}
		if(i != size) { 
			System.arraycopy(array, i, array, i + 1, size - i);//e1(arr)= source array, i1(int)= source position, e2(arr)=destination array, i2(int) = destination position, i3(int) = size
		}
		
		array[i] = e;
		size++;
		
	}
	
	private void expandArray() {
		E[] old = array;	
		this.capacity = this.capacity * 2;
		this.array =(E[]) new Object[this.capacity];
		System.arraycopy(old, 0, array, 0, size());
	}
	
	@Override
	public E remove(int i) throws IndexOutOfBoundsException {
		E old = this.get(i);
		
		if(i < size - 1) {
			System.arraycopy(array, i + 1, array, i, size - i);
		}
		array[size - 1] = null;
		size--;
		return old;
	}


	public void addFirst(E e)  {
		this.add(0, e);
		
	}
	
	public void addLast(E e)  {
		this.add(size(), e);
	}
	
	public E removeFirst() throws IndexOutOfBoundsException {
		return this.remove(0);
	}
	
	public E removeLast() throws IndexOutOfBoundsException {
		return this.remove(size() - 1);
	}
	
	
	@Override
	public Iterator<E> iterator() {
		return new ArrayListIterator();
	}
	public Object[] data() {
		return array;
	}

	

}
